@echo off
setlocal
set GRADLE_VERSION=8.10.2
set GRADLE_HOME=%USERPROFILE%\.gradle\wrapper\dists\manual-gradle-%GRADLE_VERSION%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Please run this project from GitHub Actions or install Gradle 8.10.2 locally.
  exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
