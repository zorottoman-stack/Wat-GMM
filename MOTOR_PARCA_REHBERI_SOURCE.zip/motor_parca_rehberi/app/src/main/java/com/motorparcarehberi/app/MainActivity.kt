package com.motorparcarehberi.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileOutputStream

data class Part(
    var name: String,
    var code: String,
    var alternatives: MutableList<String> = mutableListOf(),
    var note: String = "",
    var imagePath: String? = null
)

class MainActivity : Activity() {
    private val parts = mutableListOf<Part>()
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private var pendingImagePart: Part? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 16)
            setBackgroundColor(0xFF0B1020.toInt())
        }

        val title = TextView(this).apply {
            text = "MOTOR PARÇA REHBERİ"
            textSize = 22f
            setTextColor(0xFFEAF6FF.toInt())
            setPadding(0, 0, 0, 16)
        }
        root.addView(title)

        search = EditText(this).apply {
            hint = "Parça adı veya kod ara..."
            textSize = 16f
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF8EA3B8.toInt())
            setBackgroundColor(0xFF162238.toInt())
            setPadding(18, 14, 18, 14)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, 58))

        val add = Button(this).apply {
            text = "+ PARÇA EKLE"
            setOnClickListener { showPartEditor(null) }
        }
        root.addView(add, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 12 })

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 16, 0, 16)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        search.addTextChangedListener(SimpleWatcher { refresh() })
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        parts.filter { p ->
            q.isEmpty() ||
            p.name.lowercase().contains(q) ||
            p.code.lowercase().contains(q) ||
            p.alternatives.any { it.lowercase().contains(q) }
        }.forEach { addPartCard(it) }

        if (list.childCount == 0) {
            list.addView(TextView(this).apply {
                text = if (parts.isEmpty()) "Henüz parça eklenmedi." else "Sonuç bulunamadı."
                textSize = 17f
                setTextColor(0xFF9DB0C5.toInt())
                gravity = Gravity.CENTER
                setPadding(0, 50, 0, 50)
            })
        }
    }

    private fun addPartCard(part: Part) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(0xFF162238.toInt())
            setOnClickListener { showPartEditor(part) }
        }
        val name = TextView(this).apply {
            text = part.name
            textSize = 19f
            setTextColor(0xFFEAF6FF.toInt())
        }
        val code = TextView(this).apply {
            text = "Kod: ${part.code}"
            textSize = 15f
            setTextColor(0xFF73C9F5.toInt())
        }
        val alt = TextView(this).apply {
            text = "Alternatif: " + if (part.alternatives.isEmpty()) "Yok" else part.alternatives.joinToString(", ")
            textSize = 14f
            setTextColor(0xFFB5C5D8.toInt())
        }
        box.addView(name)
        box.addView(code)
        box.addView(alt)
        list.addView(box, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 })
    }

    private fun showPartEditor(existing: Part?) {
        val dialog = android.app.Dialog(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 20)
        }

        val name = EditText(this).apply { hint = "Parça adı"; setText(existing?.name ?: "") }
        val code = EditText(this).apply { hint = "Ana kod"; setText(existing?.code ?: "") }
        val alternatives = EditText(this).apply {
            hint = "Alternatif kodlar (virgülle ayır)"
            setText(existing?.alternatives?.joinToString(", ") ?: "")
        }
        val note = EditText(this).apply { hint = "Not"; setText(existing?.note ?: "") }

        val imageButton = Button(this).apply {
            text = if (existing?.imagePath != null) "Görseli değiştir" else "Galeriden görsel seç"
            setOnClickListener {
                pendingImagePart = existing
                startActivityForResult(Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 1001)
            }
        }

        val save = Button(this).apply {
            text = "KAYDET"
            setOnClickListener {
                val n = name.text.toString().trim()
                val c = code.text.toString().trim()
                if (n.isEmpty() || c.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Parça adı ve kod gerekli.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val target = existing ?: Part(n, c)
                target.name = n
                target.code = c
                target.alternatives = alternatives.text.toString()
                    .split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .toMutableList()
                target.note = note.text.toString()
                if (existing == null) parts.add(target)
                dialog.dismiss()
                refresh()
            }
        }

        container.addView(name)
        container.addView(code)
        container.addView(alternatives)
        container.addView(note)
        container.addView(imageButton)
        container.addView(save)
        dialog.setContentView(container)
        dialog.setTitle(if (existing == null) "Parça Ekle" else "Parçayı Düzenle")
        dialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            val part = pendingImagePart
            if (part != null) {
                part.imagePath = copyImageToAppStorage(uri)
                Toast.makeText(this, "Görsel uygulamaya kaydedildi.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun copyImageToAppStorage(uri: Uri): String? {
        return try {
            val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, uri)
            val file = File(filesDir, "part_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private class SimpleWatcher(val action: () -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { action() }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
