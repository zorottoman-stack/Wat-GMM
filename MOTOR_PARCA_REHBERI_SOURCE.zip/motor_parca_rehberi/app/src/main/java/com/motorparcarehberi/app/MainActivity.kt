package com.motorparcarehberi.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale

data class Part(
    var id: Long = System.currentTimeMillis(),
    var name: String,
    var code: String,
    var alternatives: MutableList<String> = mutableListOf(),
    var note: String = "",
    var imagePath: String? = null
)

class MainActivity : Activity() {

    private val parts = mutableListOf<Part>()
    private lateinit var results: LinearLayout
    private lateinit var search: EditText
    private lateinit var countText: TextView

    private var editorDialog: AlertDialog? = null
    private var detailsDialog: AlertDialog? = null
    private var pendingImagePath: String? = null
    private var pendingPreview: ImageView? = null

    private val bg = Color.rgb(7, 11, 18)
    private val panel = Color.rgb(14, 20, 30)
    private val panel2 = Color.rgb(18, 26, 38)
    private val cyan = Color.rgb(78, 225, 232)
    private val white = Color.rgb(239, 246, 252)
    private val muted = Color.rgb(139, 157, 177)
    private val line = Color.rgb(39, 53, 70)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadParts()
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::results.isInitialized) refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(18), dp(20), dp(12))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val title = TextView(this).apply {
            text = "MOTOR PARÇA"
            textSize = 25f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(white)
            letterSpacing = 0.04f
        }

        val subtitle = TextView(this).apply {
            text = "Hızlı referans • parça kodu • görsel"
            textSize = 12.5f
            setTextColor(muted)
            setPadding(0, dp(3), 0, 0)
        }

        titleBox.addView(title)
        titleBox.addView(subtitle)
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))

        val add = TextView(this).apply {
            text = "+"
            textSize = 28f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(bg)
            background = rounded(cyan, 18f)
            elevation = dp(5).toFloat()
            setOnClickListener { showEditor(null) }
            contentDescription = "Yeni parça ekle"
        }
        header.addView(add, LinearLayout.LayoutParams(dp(52), dp(52)))

        root.addView(header)

        val searchPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(12), 0)
            background = rounded(panel2, 18f, cyan, 1)
        }

        val searchIcon = TextView(this).apply {
            text = "⌕"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(cyan)
        }
        searchPanel.addView(searchIcon, LinearLayout.LayoutParams(dp(34), dp(58)))

        search = EditText(this).apply {
            hint = "Parça adı veya kod ara..."
            textSize = 16f
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(muted)
            background = null
            setPadding(0, 0, 0, 0)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        searchPanel.addView(search, LinearLayout.LayoutParams(0, dp(58), 1f))

        val clear = TextView(this).apply {
            text = "×"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setOnClickListener { search.setText("") }
        }
        searchPanel.addView(clear, LinearLayout.LayoutParams(dp(38), dp(58)))

        val searchParams = LinearLayout.LayoutParams(-1, dp(62))
        searchParams.topMargin = dp(20)
        root.addView(searchPanel, searchParams)

        val infoRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(14), dp(2), dp(8))
        }

        countText = TextView(this).apply {
            textSize = 12f
            setTextColor(muted)
        }
        infoRow.addView(countText, LinearLayout.LayoutParams(0, -2, 1f))

        val hint = TextView(this).apply {
            text = "Dokun → detay"
            textSize = 11.5f
            setTextColor(Color.rgb(104, 126, 149))
        }
        infoRow.addView(hint)

        root.addView(infoRow)

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            isFillViewport = true
        }

        results = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, dp(24))
        }
        scroll.addView(results)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                refresh()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        setContentView(root)
        refresh()
    }

    private fun refresh() {
        if (!::results.isInitialized) return
        results.removeAllViews()

        val q = search.text.toString().trim().lowercase(Locale.getDefault())
        val filtered = parts.filter { p ->
            q.isEmpty() ||
                p.name.lowercase(Locale.getDefault()).contains(q) ||
                p.code.lowercase(Locale.getDefault()).contains(q) ||
                p.alternatives.any { it.lowercase(Locale.getDefault()).contains(q) }
        }

        countText.text = if (q.isEmpty()) {
            "${parts.size} kayıt"
        } else {
            "${filtered.size} sonuç"
        }

        if (filtered.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(70), dp(20), dp(40))
            }
            val icon = TextView(this).apply {
                text = "⌕"
                textSize = 42f
                setTextColor(Color.rgb(49, 70, 91))
                gravity = Gravity.CENTER
            }
            val title = TextView(this).apply {
                text = if (parts.isEmpty()) "Henüz parça eklenmedi" else "Parça bulunamadı"
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(white)
                gravity = Gravity.CENTER
            }
            val sub = TextView(this).apply {
                text = if (parts.isEmpty()) "Sağ üstteki + ile ilk kaydı oluştur." else "Parça adı, ana kod veya alternatif kod ile tekrar dene."
                textSize = 13f
                setTextColor(muted)
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, 0)
            }
            empty.addView(icon)
            empty.addView(title)
            empty.addView(sub)
            results.addView(empty, LinearLayout.LayoutParams(-1, -2))
            return
        }

        filtered.forEach { addResult(it) }
    }

    private fun addResult(part: Part) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(14), dp(10))
            background = rounded(panel, 16f, line, 1)
            setOnClickListener { showDetails(part) }
        }

        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(23, 31, 43), 14f)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        loadInto(image, part.imagePath)
        row.addView(image, LinearLayout.LayoutParams(dp(72), dp(72)))

        val textBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(6), 0)
        }

        val name = TextView(this).apply {
            text = part.name
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val code = TextView(this).apply {
            text = part.code
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(cyan)
            setPadding(0, dp(5), 0, 0)
        }

        val altText = if (part.alternatives.isEmpty()) {
            "Alternatif kod yok"
        } else {
            "ALT  " + part.alternatives.take(2).joinToString("  •  ")
        }

        val alt = TextView(this).apply {
            text = altText
            textSize = 11.5f
            setTextColor(muted)
            setPadding(0, dp(5), 0, 0)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        textBox.addView(name)
        textBox.addView(code)
        textBox.addView(alt)
        row.addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))

        val arrow = TextView(this).apply {
            text = "›"
            textSize = 28f
            setTextColor(Color.rgb(83, 107, 130))
            gravity = Gravity.CENTER
        }
        row.addView(arrow, LinearLayout.LayoutParams(dp(24), dp(48)))

        val lp = LinearLayout.LayoutParams(-1, dp(94))
        lp.bottomMargin = dp(9)
        results.addView(row, lp)
    }

    private fun showDetails(part: Part) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(18))
            background = rounded(panel, 24f)
        }

        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(22, 30, 42), 18f)
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        loadInto(image, part.imagePath)
        box.addView(image, LinearLayout.LayoutParams(-1, dp(220)))

        val title = TextView(this).apply {
            text = part.name
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            setPadding(0, dp(18), 0, 0)
        }
        box.addView(title)

        val mainCode = detailLine("ANA KOD", part.code, true)
        box.addView(mainCode, LinearLayout.LayoutParams(-1, -2))

        val alternatives = if (part.alternatives.isEmpty()) "Yok" else part.alternatives.joinToString(" • ")
        box.addView(detailLine("ALTERNATİF KODLAR", alternatives, false))

        if (part.note.isNotBlank()) {
            box.addView(detailLine("NOT", part.note, false))
        }

        val buttons = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(18), 0, 0)
        }

        val edit = TextView(this).apply {
            text = "DÜZENLE"
            textSize = 12f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cyan)
            background = rounded(Color.TRANSPARENT, 14f, cyan, 1)
            setOnClickListener {
                detailsDialog?.dismiss()
                showEditor(part)
            }
        }

        val delete = TextView(this).apply {
            text = "SİL"
            textSize = 12f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(255, 117, 117))
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Parçayı sil?")
                    .setMessage(part.name)
                    .setNegativeButton("İptal", null)
                    .setPositiveButton("Sil") { _, _ ->
                        parts.removeAll { it.id == part.id }
                        part.imagePath?.let { File(it).delete() }
                        saveParts()
                        detailsDialog?.dismiss()
                        refresh()
                        Toast.makeText(this@MainActivity, "Parça silindi.", Toast.LENGTH_SHORT).show()
                    }.show()
            }
        }

        buttons.addView(edit, LinearLayout.LayoutParams(0, dp(46), 1f))
        buttons.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        buttons.addView(delete, LinearLayout.LayoutParams(0, dp(46), 1f))
        box.addView(buttons)

        detailsDialog = AlertDialog.Builder(this)
            .setView(box)
            .create()

        detailsDialog?.show()
        detailsDialog?.window?.setBackgroundDrawable(rounded(panel, 24f))
    }

    private fun detailLine(label: String, value: String, accent: Boolean): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, 0)
        }
        val l = TextView(this).apply {
            text = label
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(89, 112, 137))
            letterSpacing = 0.08f
        }
        val v = TextView(this).apply {
            text = value
            textSize = if (accent) 16f else 14f
            setTextColor(if (accent) cyan else white)
            setPadding(0, dp(5), 0, 0)
        }
        box.addView(l)
        box.addView(v)
        return box
    }

    private fun showEditor(existing: Part?) {
        pendingImagePath = existing?.imagePath

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(18))
            background = rounded(panel, 24f)
        }

        val heading = TextView(this).apply {
            text = if (existing == null) "Yeni parça" else "Parçayı düzenle"
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
        }
        box.addView(heading)

        val helper = TextView(this).apply {
            text = "Parça bilgilerini gir, ardından görseli ekle."
            textSize = 12.5f
            setTextColor(muted)
            setPadding(0, dp(5), 0, dp(16))
        }
        box.addView(helper)

        pendingPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(22, 30, 42), 18f)
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        loadInto(pendingPreview!!, pendingImagePath)
        box.addView(pendingPreview, LinearLayout.LayoutParams(-1, dp(190)))

        val imageButton = TextView(this).apply {
            text = if (existing?.imagePath != null) "GÖRSELİ DEĞİŞTİR" else "GALERİDEN GÖRSEL SEÇ"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(cyan)
            background = rounded(Color.TRANSPARENT, 14f, cyan, 1)
            setOnClickListener {
                startActivityForResult(
                    Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI),
                    1001
                )
            }
        }
        val imageLp = LinearLayout.LayoutParams(-1, dp(46))
        imageLp.topMargin = dp(10)
        box.addView(imageButton, imageLp)

        val name = field("PARÇA ADI", "Örn. Motor Kapağı", existing?.name ?: "")
        val code = field("ANA KOD", "Örn. 6205-2RS", existing?.code ?: "")
        val alternatives = field(
            "ALTERNATİF KODLAR",
            "Virgülle ayır: 6205-2Z, 6205-C3",
            existing?.alternatives?.joinToString(", ") ?: ""
        )
        val note = field("NOT", "İsteğe bağlı açıklama", existing?.note ?: "")

        box.addView(name.first)
        box.addView(code.first)
        box.addView(alternatives.first)
        box.addView(note.first)

        val save = TextView(this).apply {
            text = "KAYDET"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(bg)
            background = rounded(cyan, 15f)
            setOnClickListener {
                val n = name.second.text.toString().trim()
                val c = code.second.text.toString().trim()
                if (n.isEmpty() || c.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Parça adı ve ana kod gerekli.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val target = existing ?: Part(name = n, code = c)
                target.name = n
                target.code = c
                target.alternatives = alternatives.second.text.toString()
                    .split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .toMutableList()
                target.note = note.second.text.toString().trim()
                target.imagePath = pendingImagePath

                if (existing == null) parts.add(target)
                saveParts()
                editorDialog?.dismiss()
                refresh()
                Toast.makeText(this@MainActivity, "Parça kaydedildi.", Toast.LENGTH_SHORT).show()
            }
        }

        val saveLp = LinearLayout.LayoutParams(-1, dp(50))
        saveLp.topMargin = dp(18)
        box.addView(save, saveLp)

        scroll.addView(box)

        editorDialog = AlertDialog.Builder(this)
            .setView(scroll)
            .create()

        editorDialog?.setOnDismissListener {
            pendingPreview = null
            pendingImagePath = null
        }

        editorDialog?.show()
        editorDialog?.window?.setBackgroundDrawable(rounded(panel, 24f))
        editorDialog?.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94f).toInt(),
            (resources.displayMetrics.heightPixels * 0.88f).toInt()
        )
    }

    private fun field(label: String, hint: String, value: String): Pair<LinearLayout, EditText> {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(13), 0, 0)
        }

        val labelView = TextView(this).apply {
            text = label
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(89, 112, 137))
            letterSpacing = 0.08f
        }

        val input = EditText(this).apply {
            this.hint = hint
            setText(value)
            textSize = 15f
            setTextColor(white)
            setHintTextColor(Color.rgb(91, 111, 133))
            background = rounded(panel2, 13f, line, 1)
            setPadding(dp(13), dp(2), dp(13), dp(2))
            minHeight = dp(50)
        }

        wrap.addView(labelView)
        wrap.addView(input, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(6) })
        return Pair(wrap, input)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 1001 && resultCode == RESULT_OK && data?.data != null) {
            val saved = copyImageToAppStorage(data.data!!)
            if (saved != null) {
                pendingImagePath = saved
                pendingPreview?.let { loadInto(it, saved) }
                Toast.makeText(this, "Görsel uygulamaya kopyalandı.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Görsel alınamadı.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun copyImageToAppStorage(uri: Uri): String? {
        return try {
            val file = File(filesDir, "part_${System.currentTimeMillis()}.jpg")
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) return null
                FileOutputStream(file).use { output ->
                    input.copyTo(output)
                }
            }
            file.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    private fun loadInto(view: ImageView, path: String?) {
        if (path.isNullOrBlank() || !File(path).exists()) {
            view.setImageDrawable(null)
            return
        }
        try {
            val bitmap = BitmapFactory.decodeFile(path)
            view.setImageBitmap(bitmap)
        } catch (_: Exception) {
            view.setImageDrawable(null)
        }
    }

    private fun saveParts() {
        val array = JSONArray()
        parts.forEach { p ->
            array.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("code", p.code)
                put("alternatives", JSONArray(p.alternatives))
                put("note", p.note)
                put("imagePath", p.imagePath ?: "")
            })
        }
        getPreferences(MODE_PRIVATE).edit()
            .putString("parts", array.toString())
            .apply()
    }

    private fun loadParts() {
        parts.clear()
        val raw = getPreferences(MODE_PRIVATE).getString("parts", null) ?: return
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val alts = mutableListOf<String>()
                val a = o.optJSONArray("alternatives")
                if (a != null) {
                    for (j in 0 until a.length()) alts.add(a.optString(j))
                }
                parts.add(
                    Part(
                        id = o.optLong("id", System.currentTimeMillis() + i),
                        name = o.optString("name"),
                        code = o.optString("code"),
                        alternatives = alts,
                        note = o.optString("note"),
                        imagePath = o.optString("imagePath").ifBlank { null }
                    )
                )
            }
        } catch (_: Exception) {
            parts.clear()
        }
    }

    private fun rounded(color: Int, radius: Float, strokeColor: Int? = null, strokeWidth: Int = 0): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius.toInt()).toFloat()
            if (strokeColor != null && strokeWidth > 0) setStroke(dp(strokeWidth), strokeColor)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt().coerceAtLeast(1)
}
