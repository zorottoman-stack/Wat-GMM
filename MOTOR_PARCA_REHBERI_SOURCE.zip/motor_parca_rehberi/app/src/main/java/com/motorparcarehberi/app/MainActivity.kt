package com.motorparcarehberi.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

private data class Part(var id:String=UUID.randomUUID().toString(), var name:String="", var code:String="", var alternatives:MutableList<String> = mutableListOf(), var note:String="", var imagePath:String="", var favorite:Boolean=false)

class MainActivity: AppCompatActivity() {
    private lateinit var store: PartStore
    private lateinit var adapter: PartAdapter
    private var pendingImagePart: Part? = null
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { saveImage(it) } }

    override fun onCreate(b: Bundle?) { super.onCreate(b); store=PartStore(this); showHome() }

    private fun showHome() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,18,20,10); setBackgroundColor(Color.rgb(5,14,24)) }
        val title=TextView(this).apply { text="Motor Parça Rehberi"; textSize=25f; setTextColor(Color.WHITE); setTypeface(null,1); setPadding(0,4,0,14) }
        root.addView(title)
        val search=EditText(this).apply { hint="Parça adı veya kod ara..."; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(145,160,175)); singleLine=true; setPadding(18,0,18,0); setBackgroundColor(Color.rgb(20,32,46)) }
        root.addView(search, LinearLayout.LayoutParams(-1,58).apply{bottomMargin=12})
        val count=TextView(this).apply { setTextColor(Color.rgb(155,180,205)); textSize=13f }
        root.addView(count)
        val rv=RecyclerView(this).apply { layoutManager=LinearLayoutManager(this@MainActivity) }
        adapter=PartAdapter(mutableListOf(), { p->showDetail(p) }, {p->showEditor(p)})
        rv.adapter=adapter; root.addView(rv,LinearLayout.LayoutParams(-1,0,1f))
        val add=Button(this).apply { text="＋  Parça Ekle"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(21,151,255)); setOnClickListener{showEditor(null)} }
        root.addView(add,LinearLayout.LayoutParams(-1,58).apply{topMargin=10})
        setContentView(root)
        fun refresh(q:String="") { val all=store.all(); val f=all.filter{ val x=q.trim().lowercase(); x.isEmpty() || it.name.lowercase().contains(x)||it.code.lowercase().contains(x)||it.alternatives.any{a->a.lowercase().contains(x)} }; adapter.items=f.toMutableList(); adapter.notifyDataSetChanged(); count.text="${f.size} kayıt" }
        refresh(); search.addTextChangedListener(SimpleTextWatcher{refresh(it)})
    }

    private fun showDetail(p:Part) {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,18,22,22);setBackgroundColor(Color.rgb(5,14,24))}
        val back=Button(this).apply{text="‹ Geri";setOnClickListener{showHome()};gravity=Gravity.LEFT}
        root.addView(back)
        val h=TextView(this).apply{text=p.name; textSize=27f;setTextColor(Color.WHITE);setTypeface(null,1)};root.addView(h)
        val c=TextView(this).apply{text="Ana kod: ${p.code}";textSize=17f;setTextColor(Color.rgb(65,175,255));setPadding(0,8,0,14)};root.addView(c)
        if(p.imagePath.isNotEmpty()){ val iv=ImageView(this).apply{setImageURI(Uri.fromFile(File(p.imagePath)));adjustViewBounds=true;scaleType=ImageView.ScaleType.CENTER_CROP};root.addView(iv,LinearLayout.LayoutParams(-1,240).apply{bottomMargin=12}) }
        val alt=TextView(this).apply{text="Alternatif kodlar";textSize=18f;setTextColor(Color.WHITE);setTypeface(null,1)};root.addView(alt)
        root.addView(TextView(this).apply{text=if(p.alternatives.isEmpty())"Alternatif kod yok" else p.alternatives.joinToString("\n• ",prefix="• ");textSize=16f;setTextColor(Color.LTGRAY);setPadding(0,8,0,16)})
        if(p.note.isNotBlank()) root.addView(TextView(this).apply{text="Not\n${p.note}";textSize=16f;setTextColor(Color.LTGRAY);setPadding(0,8,0,18)})
        val edit=Button(this).apply{text="Düzenle";setOnClickListener{showEditor(p)}};root.addView(edit)
        setContentView(root)
    }

    private fun showEditor(existing:Part?) {
        val p=existing ?: Part(); val root=ScrollView(this); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,18,22,28);setBackgroundColor(Color.rgb(5,14,24))};root.addView(box)
        box.addView(Button(this).apply{text="‹ Geri";setOnClickListener{showHome()}})
        box.addView(TextView(this).apply{text=if(existing==null)"Yeni Parça" else "Parçayı Düzenle";textSize=26f;setTextColor(Color.WHITE);setTypeface(null,1);setPadding(0,8,0,18)})
        val image=ImageView(this).apply{setBackgroundColor(Color.rgb(20,32,46));scaleType=ImageView.ScaleType.CENTER_CROP; if(p.imagePath.isNotEmpty())setImageURI(Uri.fromFile(File(p.imagePath)))};box.addView(image,LinearLayout.LayoutParams(-1,210).apply{bottomMargin=8})
        val imgBtn=Button(this).apply{text="📷  Görsel Seç";setOnClickListener{pendingImagePart=p;pickImage.launch("image/*")}};box.addView(imgBtn)
        val name=field("Parça adı",p.name);box.addView(name.first);val code=field("Ana kod",p.code);box.addView(code.first)
        val alts=field("Alternatif kodlar (virgülle ayır)",p.alternatives.joinToString(", "));box.addView(alts.first)
        val note=field("Not",p.note);box.addView(note.first)
        box.addView(Button(this).apply{text="✓  KAYDET";setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(21,151,255));setOnClickListener{
            p.name=name.second.text.toString().trim();p.code=code.second.text.toString().trim();p.alternatives=alts.second.text.toString().split(",").map{it.trim()}.filter{it.isNotBlank()}.toMutableList();p.note=note.second.text.toString(); if(p.name.isBlank()||p.code.isBlank()){Toast.makeText(this@MainActivity,"Parça adı ve ana kod gerekli",Toast.LENGTH_SHORT).show();return@setOnClickListener};store.save(p);showDetail(p)}})
        if(existing!=null) box.addView(Button(this).apply{text="Parçayı Sil";setOnClickListener{MaterialAlertDialogBuilder(this@MainActivity).setTitle("Parça silinsin mi?").setMessage("Bu kayıt ve uygulama içindeki görseli silinecek.").setNegativeButton("İptal",null).setPositiveButton("Sil"){_,_->store.delete(p);showHome()}.show()}})
        setContentView(root)
    }

    private fun field(label:String,value:String):Pair<TextInputLayout,TextInputEditText>{val l=TextInputLayout(this);l.hint=label;val e=TextInputEditText(this);e.setText(value);e.setTextColor(Color.WHITE);l.addView(e);l.setPadding(0,5,0,5);return l to e}
    private fun saveImage(uri:Uri){pendingImagePart?.let{p->val ext=".jpg";val file=File(filesDir,"img_${p.id}$ext");contentResolver.openInputStream(uri)?.use{input->FileOutputStream(file).use{output->input.copyTo(output)}};p.imagePath=file.absolutePath;store.save(p);showEditor(p)}}
}

class PartStore(private val a:Activity){private val prefs=a.getSharedPreferences("parts",0);private val key="data";fun all():MutableList<Part>{val ar=JSONArray(prefs.getString(key,"[]"));val out=mutableListOf<Part>();for(i in 0 until ar.length()){val o=ar.getJSONObject(i);out.add(Part(o.getString("id"),o.getString("name"),o.getString("code"),o.optJSONArray("alt")?.let{x->MutableList(x.length()){j->x.getString(j)}}?:mutableListOf(),o.optString("note"),o.optString("image"),o.optBoolean("fav")))};return out}fun save(p:Part){val all=all();val i=all.indexOfFirst{it.id==p.id};if(i>=0)all[i]=p else all.add(0,p);val ar=JSONArray();all.forEach{p->ar.put(JSONObject().apply{put("id",p.id);put("name",p.name);put("code",p.code);put("alt",JSONArray(p.alternatives));put("note",p.note);put("image",p.imagePath);put("fav",p.favorite)})};prefs.edit().putString(key,ar.toString()).apply()}fun delete(p:Part){File(p.imagePath).takeIf{it.isFile}?.delete();saveDelete(p.id)}private fun saveDelete(id:String){val ar=JSONArray();all().filter{it.id!=id}.forEach{p->ar.put(JSONObject().apply{put("id",p.id);put("name",p.name);put("code",p.code);put("alt",JSONArray(p.alternatives));put("note",p.note);put("image",p.imagePath);put("fav",p.favorite)})};prefs.edit().putString(key,ar.toString()).apply()}}

class PartAdapter(var items:MutableList<Part>,private val click:(Part)->Unit,private val edit:(Part)->Unit):RecyclerView.Adapter<PartAdapter.VH>(){class VH(v:LinearLayout):RecyclerView.ViewHolder(v);override fun onCreateViewHolder(p:android.view.ViewGroup,t:Int):VH{val l=LinearLayout(p.context).apply{orientation=LinearLayout.VERTICAL;setPadding(18,14,18,14);setBackgroundColor(Color.rgb(18,30,43))};return VH(l)}override fun getItemCount()=items.size;override fun onBindViewHolder(h:VH,pos:Int){val l=h.itemView as LinearLayout;l.removeAllViews();val p=items[pos];l.addView(TextView(l.context).apply{text=p.name;textSize=19f;setTextColor(Color.WHITE);setTypeface(null,1)});l.addView(TextView(l.context).apply{text="${p.code}  •  ${p.alternatives.size} alternatif";textSize=14f;setTextColor(Color.rgb(90,180,255));setPadding(0,5,0,0)});l.setOnClickListener{click(p)};l.setOnLongClickListener{edit(p);true};val lp=l.layoutParams?:RecyclerView.LayoutParams(-1,-2);lp.width=-1;lp.height=android.view.ViewGroup.LayoutParams.WRAP_CONTENT;lp.let{l.layoutParams=it}}}

class SimpleTextWatcher(private val f:(String)->Unit):android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){f(s?.toString()?:(""))};override fun afterTextChanged(e:android.text.Editable?) {}}
