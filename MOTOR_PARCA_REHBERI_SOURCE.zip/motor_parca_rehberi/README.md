# Motor Parça Rehberi — V1

Android uygulaması: motor parçalarının adını, ana kodunu, alternatif kodlarını, notlarını ve görsellerini cihaz üzerinde saklar.

## Özellikler
- Parça adı + ana kod + alternatif kodlarda anlık arama
- Bir parçaya birden fazla alternatif kod bağlama
- Galeriden seçilen görseli uygulamanın özel depolamasına kopyalama
- Galerideki orijinal fotoğraf silinse bile uygulama içindeki kopyanın kalması
- İnternetsiz çalışma
- Parça ekleme, düzenleme ve silme

## APK
GitHub Actions workflow'u `build-motor-parca-rehberi.yml` Android Debug APK üretir.
