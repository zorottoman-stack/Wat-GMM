# Motor Parça Rehberi V1

Genel maksatlı motor parçaları için yerel referans uygulaması.

Özellikler:
- Parça adı
- Ana kod
- Birden fazla alternatif kod
- Not
- Parça adı / ana kod / alternatif kod ile arama
- Galeriden görsel seçme
- Seçilen görseli uygulamanın kendi depolamasına kopyalama
- İnternetsiz çalışma

Görsel uygulamaya kopyalandığı için galerideki orijinal fotoğraf silinse bile uygulamadaki kopya kalır.
